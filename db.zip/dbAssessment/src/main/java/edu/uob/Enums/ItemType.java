package edu.uob.Enums;

public enum ItemType {
	OLD,
	NEW;
}
