abstract public class AbstractCard {
    abstract void stateAPR();
    abstract void accept(Visitor v);
}
