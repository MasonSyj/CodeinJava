abstract public class Mammal {
    abstract void makeNoise();
    abstract void accept(Visitor v);
}
