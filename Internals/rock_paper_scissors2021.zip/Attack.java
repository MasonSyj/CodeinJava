public abstract class Attack {
    public abstract void handle(Attack a);
    public abstract void handleRock(Attack a);
    public abstract void handlePaper(Attack a);
    public abstract void handleScissors(Attack a);
}
