public class Animal {

  public String eat(Food food) {
    return food.eaten(this);
  }

}
