public class Dog extends Animal {

  //TODO:
  
}
