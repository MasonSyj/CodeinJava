public class Fruit extends Food {

  //TODO:
  
}
