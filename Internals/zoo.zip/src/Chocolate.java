public class Chocolate extends Food {

  //TODO:
  
}
