package edu.uob.Enums;

public enum WildType {
    STAR,
    ATTRIBUTELIST
}
