package edu.uob.Enums;

public enum CommandType {
	USE,
	CREATE,
	INSERT,
	SELECT,
	UPDATE,
	ALTER,
	DELETE,
	DROP,
	JOIN
}
