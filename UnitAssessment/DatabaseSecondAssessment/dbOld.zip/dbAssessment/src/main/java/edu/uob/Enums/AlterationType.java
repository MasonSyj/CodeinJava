package edu.uob.Enums;

public enum AlterationType {
    ADD,
    DROP
}
