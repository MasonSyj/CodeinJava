package edu.uob;

import edu.uob.Exceptions.interpException;

public interface Writeable {
	void write2File() throws interpException;
}
