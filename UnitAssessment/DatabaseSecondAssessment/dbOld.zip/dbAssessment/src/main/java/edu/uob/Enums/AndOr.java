package edu.uob.Enums;

public enum AndOr {
    AND,
    OR
}
