package edu.uob;

public enum TriangleType {
    EQUILATERAL,
    ISOSCELES,
    SCALENE,
    RIGHT,
    FLAT,
    IMPOSSIBLE,
    ILLEGAL

}
