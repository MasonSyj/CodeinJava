package edu.uob;

class Circle extends TwoDimensionalShape {
  int radius;

  public Circle(int r) {
    radius = r;
  }

  @Override
  public double calculateArea() {
    return (int) Math.round(Math.PI * radius * radius);
  }
  @Override
  public int calculatePerimeterLength() {
    return (int) Math.round(Math.PI * radius * 2.0);
  }

  public String toString() {
    return "Circle with radius " + radius;
  }

  public void setCol(Colour c){
    col = c;
  }

  public Colour getCol(){
    System.out.println(col);
    return col;
  }
}
