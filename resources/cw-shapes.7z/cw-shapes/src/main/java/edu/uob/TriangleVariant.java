package edu.uob;

public enum TriangleVariant {
  EQUILATERAL,
  ISOSCELES,
  SCALENE,
  RIGHT,
  FLAT,
  IMPOSSIBLE,
  ILLEGAL;
}
