package edu.uob;

public enum Colour {
  RED,
  GREEN,
  BLUE,
  YELLOW,
  CYAN,
  PURPLE,
  PINK,
  ORANGE,
  BROWN,
  WHITE,
  BLACK,
  GREY
}
