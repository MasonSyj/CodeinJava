package edu.uob;

interface MultiVariantShape {
  TriangleVariant getVariant();
}
